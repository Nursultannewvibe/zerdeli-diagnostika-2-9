#!/usr/bin/env python3
"""Проставляет в тесты подтверждённые ключи из _src/kluchi.json.

Ключ здесь — не догадка: он либо взят прямо из служебного листа таблицы ответов
формы, либо восстановлен по баллам учеников так, что сходится у всех до балла.
Поэтому он кладётся в `correct`, а мои прежние предположения (`correctProposed`)
удаляются. Там, где ключа нет или он спорный, предположение остаётся как было.
"""
import json, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
TESTS = ROOT / 'tests'
L = 'ABCDE'


def apply_one(tid, spec):
    path = TESTS / (tid + '.json')
    d = json.loads(path.read_text(encoding='utf-8'))
    key = spec['key']
    qs = d['questions']
    if len(key) != len(qs):
        print(f"{tid}: ключ на {len(key)} вопросов, в тесте {len(qs)} — пропущен")
        return
    filled = skipped = changed = 0
    for q, ch in zip(qs, key):
        if ch == '?':                       # спорный вопрос — ключа нет
            q['needsReview'] = spec.get('note', 'ключ не сошёлся, нужен исходник')
            skipped += 1
            continue
        idx = L.index(ch)
        if idx >= len(q.get('options') or []):
            q['needsReview'] = (f"в форме верный вариант {ch}, а у нас всего "
                                f"{len(q.get('options') or [])} вариантов — потерян вариант ответа")
            skipped += 1
            continue
        if q.get('correctProposed') is not None and q['correctProposed'] != idx:
            changed += 1
        q['correct'] = idx
        q.pop('correctProposed', None)
        # needsReview НЕ трогаем: он про потерянную формулу или картинку, а не про ключ —
        # вопрос без условия нельзя показывать ученику, даже когда верный ответ известен
        filled += 1
    # вопросы с потерянной формулой движок не показывает, поэтому и в готовность не считаем
    shown = [q for q in qs if not q.get('needsReview')]
    d['answersFilled'] = bool(shown) and all(q.get('correct') is not None for q in shown)
    d['keySource'] = spec['source']
    if spec.get('exact'):
        d['keyNote'] = spec['exact']
    if d['answersFilled']:
        d.pop('proposedBy', None); d.pop('proposedNote', None)
    path.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding='utf-8')
    print(f"{tid}: заполнено {filled}, спорных {skipped}, "
          f"мой ответ был другим у {changed} — готов: {'да' if d['answersFilled'] else 'нет'}")


def rebuild_manifest():
    m = json.loads((TESTS / 'manifest.json').read_text(encoding='utf-8'))
    for t in m['tests']:
        d = json.loads((TESTS / (t['id'] + '.json')).read_text(encoding='utf-8'))
        shown = [q for q in d['questions'] if not q.get('needsReview')]
        d['answersFilled'] = bool(shown) and all(q.get('correct') is not None for q in shown)
        (TESTS / (t['id'] + '.json')).write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding='utf-8')
        t['questions'] = len(shown)          # столько вопросов реально увидит ученик
        t['hidden'] = len(d['questions']) - len(shown)
        t['ready'] = d['answersFilled']
        t['proposed'] = any(q.get('correctProposed') is not None for q in shown)
    (TESTS / 'manifest.json').write_text(json.dumps(m, ensure_ascii=False, indent=1), encoding='utf-8')
    ready = [t['id'] for t in m['tests'] if t['ready']]
    print(f"\nmanifest.json обновлён. Готовых тестов: {len(ready)} — {', '.join(ready)}")


if __name__ == '__main__':
    spec = json.loads((ROOT / '_src' / 'kluchi.json').read_text(encoding='utf-8'))
    for tid, s in spec.items():
        if tid.startswith('_') or 'key' not in s:
            continue
        apply_one(tid, s)
    rebuild_manifest()
