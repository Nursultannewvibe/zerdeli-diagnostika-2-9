#!/usr/bin/env python3
"""Машинная проверка ответов теста 9 класса.

Ключа к этому тесту нет ни в форме, ни в таблице ответов — восстанавливать не по чему.
Задания при этом однозначные: степени, тождества, уравнения, площади. Поэтому каждый
ответ здесь не «решён», а посчитан символьно (sympy) и сверен с вариантами из .docx.
Текст заданий взят дословно из 9synypmatematikasynaqtesti.docx.
"""
from sympy import (symbols, simplify, sqrt, Rational, expand, solve, S, Eq,
                   solveset, Interval, Union, factor, sin, rad, nsimplify, Max)

m, n, a, b, x, y = symbols('m n a b x y')
L = 'ABCDE'
checks = []


def check(num, expr, options, note=''):
    """Ищет, какой из вариантов равен посчитанному значению."""
    hits = [i for i, o in enumerate(options)
            if o is not None and simplify(expr - o) == 0]
    checks.append((num, L[hits[0]] if len(hits) == 1 else '?',
                   str(expr), len(hits), note))


# --- степени и тождества -------------------------------------------------
check(1, (3**2)**2, [9, 81, 243, Rational(1, 81), 12])
check(2, (-Rational(4, 10) * x)**2, [-Rational(16, 100) * x, -Rational(16, 100) * x**2,
                                     Rational(4, 10) * x**2, Rational(16, 100) * x**2,
                                     Rational(16, 10) * x**2])
check(3, Rational(7)**-3 / Rational(49)**-2, [7, 49, -7, -Rational(7, 10), Rational(1, 7)])
check(4, (m**2 * n)**3 * (m**4 * n**5)**2 / (m**4 * n**5)**3,
      [m**3 * n**4, m**8 * n, n**2, m**2 * n**2, m**2 / n**2])
check(5, expand((5 * x - 2 * y)**2),
      [25 * x**2 - 20 * x * y + 4 * y**2, 25 * x**2 - 4 * y**2, 25 * x**2 + 4 * y**2,
       25 * x**2 - 10 * x * y + 4 * y**2, 5 * x**2 - 10 * x * y + 2 * y**2])
check(6, expand((b**2 - a**2) * (a**2 + b**2)),
      [a**4 - b**4, a**4 + b**4, b**4 - a**4, a**2 * b**2 - b**4, a**2 * b**2 + b**4])
check(7, simplify(x**2 / (x**2 - y**2) * (x - y) / x),
      [x, x + y, x / (x + y), S(1), (x + y) / x])
check(8, simplify(a / (a - b) / ((a + b) / b + b / (a - b))),
      [1 / a, a - b, S(1), a, b / a])

# --- корни ---------------------------------------------------------------
check(9, sqrt(Rational(49, 100)) + 1,
      [Rational(149, 100), Rational(17, 10), 8, Rational(8, 10), Rational(7, 10)])
check(10, Rational(4, 5) * sqrt(625), [20, 100, Rational(1, 4), Rational(2, 10), 200])
check(11, 2 * sqrt(20) - 2 * sqrt(45) + Rational(1, 2) * sqrt(180),
      [2 * sqrt(5), 3, S(0), sqrt(5), sqrt(40)])

# --- уравнения и неравенства --------------------------------------------
r12 = solve(Eq(x**2 - 81, 0), x)
checks.append((12, 'C' if set(r12) == {9, -9} else '?', f'корни {r12}', 1, 'варианты: ±81, 9, ±9, 81, -9'))
r13 = solve(Eq(x**2 - 2 * x - 8, 0), x)
checks.append((13, 'E' if set(r13) == {-2, 4} else '?', f'корни {r13}', 1, 'вариант E: -2; 4'))
s14 = solveset(x**2 + 3 * x + 2 < 0, x, S.Reals)
checks.append((14, 'B' if s14 == Interval.open(-2, -1) else '?', str(s14), 1, 'вариант B: (-2; -1)'))
s15 = solveset((x - 1) / (x + 1) >= 2, x, S.Reals)
checks.append((15, '?', str(s15), 0,
               'в вариантах такого промежутка нет: A (1;3) B (1;+oo) C (-oo;-3]U(1;+oo) '
               'D [-3; 1) E (-oo;+oo). Ближе всего D, но у него потерян минус перед единицей'))

# --- геометрия -----------------------------------------------------------
# 16. прямоугольная трапеция: две меньшие стороны по 12, наибольший угол 135°,
#     значит четвёртый угол 45°, высота 12, снос наклонной стороны 12/tan(45°)=12
h16, base_small = 12, 12
s16 = Rational(base_small + (base_small + 12), 2) * h16
check(16, s16, [216, 144, 72, 48, 81], 'высота 12, основания 12 и 24')

# 17. S=60, h=2 -> сумма оснований 60; отношение 5:7 -> 25 и 35
summ = Rational(2 * 60, 2)                      # S = (a+b)/2 * h  ->  a+b = 2S/h
pair = (Rational(5, 12) * summ, Rational(7, 12) * summ)
checks.append((17, 'D' if pair == (S(25), S(35)) else '?', f'основания {pair}', 1,
               'вариант D: 25 см и 35 см'))

# 18. равнобедренная трапеция, основания 15 и 17, угол 45° -> высота (17-15)/2=1
h18 = Rational(17 - 15, 2)
check(18, Rational(15 + 17, 2) * h18, [8, 16, 32, Rational(255, 2), Rational(259, 2)],
      'высота 1')

# 19. равнобедренный треугольник, основание 6, боковая 10 -> h=sqrt(100-9)
check(19, Rational(1, 2) * 6 * sqrt(10**2 - 3**2),
      [3 * sqrt(91), 6 * sqrt(91), 16, 30, 40], 'высота sqrt(91)')

# 20. максимум площади при данных двух сторонах — когда угол между ними 90°
check(20, Rational(1, 2) * 10 * 20, [40, 100, 200, 400, 150], 'угол 90°')

if __name__ == '__main__':
    key = {}
    for num, letter, value, hits, note in sorted(checks):
        key[num] = letter
        mark = 'ok' if letter != '?' else 'НЕТ ВЕРНОГО ВАРИАНТА'
        print(f"№{num:>2}  {letter}  {mark:<20} {value[:52]:<52} {note}")
    print('\nключ:', ''.join(key[i] if key[i] != '?' else '?' for i in range(1, 21)))
