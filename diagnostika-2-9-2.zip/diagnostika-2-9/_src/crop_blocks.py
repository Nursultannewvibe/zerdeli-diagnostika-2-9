#!/usr/bin/env python3
"""Вырезает вопрос целиком — условие вместе с вариантами ответа.

Нужно для тестов, свёрстанных в Word: там и формула в условии, и сами варианты
(дроби, корни, степени) — это текст со смещением, который при извлечении
рассыпается. Показать картинку всего блока честнее, чем склеивать обрывки.
Кнопки ответа в движке тогда подписываются просто буквами A, B, C…
"""
import re, sys, json, pathlib
import pdfplumber

OPT = re.compile(r'^\s*([A-EА-ЕВСД])\s*[).](\s|$)')
QNUM = re.compile(r'^\s*(\d{1,2})\s*[.)]\s*\S')
DPI = 200


def split_questions(pdf):
    rows = []
    for pi, page in enumerate(pdf.pages):
        for l in page.extract_text_lines() or []:
            rows.append((pi, l))
    if not rows:
        return [], 0
    left = min(l['x0'] for _, l in rows)
    qs, cur = [], None
    for pi, l in rows:
        m = QNUM.match(l['text'])
        if m and l['x0'] < left + 12 and not OPT.match(l['text']):
            cur = {'n': int(m.group(1)), 'lines': []}
            qs.append(cur)
        if cur is not None:
            cur['lines'].append((pi, l))
    return qs, left


def crop(pdf_path, out_dir, tag, only=None):
    out_dir = pathlib.Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    made = {}
    with pdfplumber.open(pdf_path) as pdf:
        qs, left = split_questions(pdf)
        for q in qs:
            if only and q['n'] not in only:
                continue
            # блок вопроса заканчивается на последней строке варианта
            last = 0
            for i, (pi, l) in enumerate(q['lines']):
                if OPT.match(l['text']):
                    last = i
            body = q['lines'][:last + 1] if last else q['lines']
            # добираем строки-хвосты варианта (знаменатели дробей)
            j = last + 1
            while j < len(q['lines']):
                pi, l = q['lines'][j]
                if l['x0'] > left + 25 or len(l['text']) < 12:
                    body.append((pi, l)); j += 1
                else:
                    break
            letters = []
            for _, l in body:
                m = OPT.match(l['text'])
                if m and m.group(1) not in letters:
                    letters.append(m.group(1))
            by_page = {}
            for pi, l in body:
                by_page.setdefault(pi, []).append(l)
            for k, (pi, ls) in enumerate(sorted(by_page.items())):
                page = pdf.pages[pi]
                top = max(0, min(l['top'] for l in ls) - 14)   # запас сверху: степени и числители дробей выходят за строку
                bot = min(page.height, max(l['bottom'] for l in ls) + 5)
                if bot - top < 12:
                    continue
                name = f"{tag}-q{q['n']:02d}" + (f"-{k+1}" if len(by_page) > 1 else "") + ".png"
                page.crop((max(0, left - 6), top, page.width - 35, bot)) \
                    .to_image(resolution=DPI).save(str(out_dir / name))
                made.setdefault(q['n'], {'images': [], 'letters': letters})['images'].append('images/' + name)
    return made


if __name__ == '__main__':
    pdf_path, tag = sys.argv[1], sys.argv[2]
    only = set(json.loads(sys.argv[3])) if len(sys.argv) > 3 else None
    res = crop(pdf_path, '/home/claude/zerdeli-tests/tests/images', tag, only)
    print(json.dumps(res, ensure_ascii=False))
