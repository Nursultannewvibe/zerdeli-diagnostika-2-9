#!/usr/bin/env python3
"""Собирает кусок кода для вставки в Webflow на страницу /test.

Файлы раздаёт GitHub Pages — тот же механизм, на котором уже работает старая
диагностика в этой репе. Значит и движок, и вопросы подключаются по прямой
ссылке: в Webflow лежат четыре строчки, а правки уезжают на сайт обычным
git push, без задержки на CDN-кэш.

    python3 _src/build_embed.py [базовый-адрес] [endpoint]

Базовый адрес по умолчанию — папка проекта на GitHub Pages.

Результат:
  build/embed.html        — вставить в Webflow (маленький, ссылается на CDN)
  build/embed-inline.html — запасной вариант: движок целиком внутри, без CDN
  build/preview.html      — открыть локально и посмотреть, как выйдет на сайте
"""
import sys, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
ENGINE = ROOT / 'engine'
OUT = ROOT / 'build'
FONTS = ("https://fonts.googleapis.com/css2?"
         "family=Unbounded:wght@700;800&family=Onest:wght@400;500;600;700&display=swap")


BASE = 'https://nursultannewvibe.github.io/zerdeli-diagnostika/diagnostika-2-9/'


def build(base=BASE, endpoint=''):
    cdn = base if base.endswith('/') else base + '/'
    OUT.mkdir(exist_ok=True)

    loader = f"""<!-- Zerdeli — движок диагностических тестов.
     Код и вопросы лежат в репозитории zerdeli-diagnostika, папка diagnostika-2-9,
     и раздаются через GitHub Pages. Здесь менять нечего: и вопросы, и сам движок
     правятся в репозитории и уезжают на сайт обычным git push. -->
<link rel="stylesheet" href="{FONTS}">
<link rel="stylesheet" href="{cdn}engine/test.css">
<div id="zd-test"></div>
<script>
  window.ZERDELI_TESTS_BASE = '{cdn}tests/';
  window.ZERDELI_ENDPOINT   = '{endpoint}';
</script>
<script src="{cdn}engine/test.js"></script>"""
    (OUT / 'embed.html').write_text(loader, encoding='utf-8')

    # запасной вариант, если CDN окажется недоступен: всё внутри страницы
    inline = (f'<!-- Zerdeli — движок тестов, вложен целиком (запасной вариант,\n'
              f'     если GitHub Pages окажется недоступен).\n'
              f'     Собрано из engine/test.css и engine/test.js. При правке движка\n'
              f'     этот кусок надо переложить в Webflow заново. -->\n'
              f'<style>@import url("{FONTS}");\n'
              + (ENGINE / 'test.css').read_text(encoding='utf-8') + '</style>\n'
              '<div id="zd-test"></div>\n'
              f"<script>\n  window.ZERDELI_TESTS_BASE = '{cdn}tests/';\n"
              f"  window.ZERDELI_ENDPOINT   = '{endpoint}';\n</script>\n"
              '<script>\n' + (ENGINE / 'test.js').read_text(encoding='utf-8') + '\n</script>')
    (OUT / 'embed-inline.html').write_text(inline, encoding='utf-8')

    # предпросмотр берёт вопросы из локальной папки: репозитория может ещё не быть
    local = inline.replace(f"window.ZERDELI_TESTS_BASE = '{cdn}tests/'",
                           "window.ZERDELI_TESTS_BASE = '../tests/'")
    (OUT / 'preview.html').write_text(
        '<!doctype html><html lang="ru"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        '<title>Zerdeli — предпросмотр страницы теста</title>'
        '<style>body{margin:0;background:#FAFAF5}'
        '@media(prefers-color-scheme:dark){body{background:#12140D}}</style>'
        '</head><body>\n' + local + '\n</body></html>', encoding='utf-8')

    print(f"build/embed.html        — {len(loader):,} знаков (это и вставляем в Webflow)")
    print(f"build/embed-inline.html — {len(inline):,} знаков (запасной вариант)")
    print(f"адрес файлов: {cdn}")
    return loader


if __name__ == '__main__':
    build(*(sys.argv[1:] or []))
