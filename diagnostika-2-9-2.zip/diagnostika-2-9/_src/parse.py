#!/usr/bin/env python3
"""Разбирает текст, выгруженный из PDF Google-формы, в черновой JSON теста.
Тексты вопросов и вариантов переносятся дословно, без переписывания."""
import re, json, pathlib, sys

SKIP = re.compile(r'^(аты[- ]жөні|телефон нөмір|сыныбыңыз|компания google|формы|\*обязательный)', re.I)
MARK = 'Отметьте только один овал.'
OTHER = re.compile(r'^(другое|новый раздел)\s*:?\s*$', re.I)
OPT_LABEL = re.compile(r'^\s*([АВСДA-D])\s*[).．.]\s+')
OPT_PREFIX = re.compile(r'^\s*([АВСДA-D])\s*[).．.]\s*')
POINTS = re.compile(r'\*?\s*\d+\s*балл\w*\s*$')


def parse(path):
    raw = pathlib.Path(path).read_text()
    lines = [l.rstrip() for l in raw.split('\n')]
    # номер страницы PDF для каждой строки — по разделителям \f
    page_of, page = [], 1
    for l in lines:
        page_of.append(page)
        page += l.count('\f')

    # начало блока вопроса: "   12.      №11. ..." или "   3.   1. ..."
    starts = [i for i, l in enumerate(lines) if re.match(r'^\s{2,}\d+\.\s{2,}\S', l)]
    starts.append(len(lines))

    questions = []
    for a, b in zip(starts, starts[1:]):
        block = lines[a:b]
        head = re.sub(r'^\s*\d+\.\s+', '', block[0]).strip()
        if SKIP.match(head):
            continue

        text_parts, options, topic = [], [], None
        in_opts = False
        for l in block:
            s = re.sub(r'^\s*\d+\.\s{2,}', '', l).strip()
            s = POINTS.sub('', s).strip().rstrip('*').strip()
            if not s:
                continue
            if s.startswith(MARK):
                in_opts = True
                continue
            if SKIP.match(s):
                continue
            m = re.match(r'^\((.+)\)$', s)
            if m and not in_opts:
                topic = m.group(1).strip()
                continue
            if in_opts:
                if OTHER.match(s):
                    continue
                options.append(s)
            else:
                text_parts.append(s)

        # если хотя бы один вариант помечен буквой — строки без буквы это перенос предыдущего
        if any(OPT_LABEL.match(o) for o in options):
            merged = []
            for o in options:
                cont = merged and not OPT_LABEL.match(o) and o[:1].islower()
                if not cont:
                    merged.append(OPT_PREFIX.sub('', o).strip())
                else:
                    merged[-1] = (merged[-1] + ' ' + o).strip()
            options = merged

        text = ' '.join(text_parts).strip()
        text = re.sub(r'^№?\s*\d+[.)]\s*', '', text).strip()
        # убрать повтор нумерации перед русской половиной: "... тап. 1. Найди ..."
        text = re.sub(r'(?<=[.?!:]) \d+\.\s+(?=[А-ЯA-Z])', ' ', text)
        if not text and not options:
            continue
        q = {
            'n': len(questions) + 1,
            'topic': topic,
            'text': text,
            'options': options,
            'image': None,
            'correct': None,      # ← заполняют учителя
            '_page': page_of[a],
        }
        if len(options) != 4:
            q['needsReview'] = ('нет вариантов — похоже на текст для чтения'
                                if not options else
                                f'вариантов {len(options)}, а не 4 — сверить с формой')
        questions.append(q)
    return questions


if __name__ == '__main__':
    for name in sys.argv[1:]:
        qs = parse(name)
        out = pathlib.Path(name).with_suffix('.draft.json')
        out.write_text(json.dumps(qs, ensure_ascii=False, indent=1))
        bad = [q['n'] for q in qs if len(q['options']) != 4]
        print(f"{name}: {len(qs)} вопросов, с темами {sum(1 for q in qs if q['topic'])}, "
              f"не 4 варианта у № {bad}")
