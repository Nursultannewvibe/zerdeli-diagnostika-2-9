#!/usr/bin/env python3
"""Переносит подтверждённые учителем ответы в тест.

На вход — JSON, который выдала страница review/index.html
(«Скачать файлом» или «Скопировать результат»).

    python3 _src/apply_review.py 6-matematika-проверено.json

Что делает: для каждого вопроса кладёт подтверждённый номер варианта в
`correct`, убирает `correctProposed`, ставит `answersFilled: true`, если
ответы есть у всех вопросов. После этого движок начинает считать результат
по этому тесту — до этого он отказывается.
"""
import json, sys, pathlib

TESTS = pathlib.Path(__file__).resolve().parent.parent / 'tests'


def apply(review_path):
    r = json.loads(pathlib.Path(review_path).read_text(encoding='utf-8'))
    path = TESTS / (r['test'] + '.json')
    d = json.loads(path.read_text(encoding='utf-8'))
    by_n = {q['n']: q for q in d['questions']}

    filled = changed = missing = 0
    for a in r['answers']:
        q = by_n.get(a['n'])
        if q is None:
            print(f"  ! вопроса №{a['n']} нет в тесте — пропущен")
            continue
        if a['correct'] is None:
            missing += 1
            continue
        if a.get('changed'):
            changed += 1
        q['correct'] = a['correct']
        q.pop('correctProposed', None)
        q.pop('needsReview', None)
        filled += 1

    d['answersFilled'] = all(q.get('correct') is not None for q in d['questions'])
    d.pop('proposedBy', None)
    if d['answersFilled']:
        d.pop('proposedNote', None)
    d['checkedBy'] = r.get('checkedBy', 'учитель')
    d['checkedAt'] = r.get('checkedAt')

    path.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding='utf-8')
    print(f"{r['test']}: заполнено {filled}, учитель поправил {changed}, "
          f"без ответа {missing}, тест готов: {'да' if d['answersFilled'] else 'нет'}")
    return d['answersFilled']


def rebuild_manifest():
    m = json.loads((TESTS / 'manifest.json').read_text(encoding='utf-8'))
    for t in m['tests']:
        d = json.loads((TESTS / (t['id'] + '.json')).read_text(encoding='utf-8'))
        t['ready'] = bool(d.get('answersFilled'))
        t['proposed'] = any(q.get('correctProposed') is not None for q in d['questions'])
    (TESTS / 'manifest.json').write_text(json.dumps(m, ensure_ascii=False, indent=1), encoding='utf-8')
    print('manifest.json обновлён')


if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    for p in sys.argv[1:]:
        apply(p)
    rebuild_manifest()
