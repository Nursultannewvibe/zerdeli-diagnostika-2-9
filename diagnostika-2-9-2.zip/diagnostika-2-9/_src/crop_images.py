#!/usr/bin/env python3
"""Вырезает картинки/формулы из PDF Google-формы и раскладывает по вопросам.

Логика: находим, где на странице начинается каждый вопрос, затем берём все
картинки страницы и приписываем каждую тому вопросу, в чей диапазон по вертикали
она попала. Вырезаем область картинки с полями и сохраняем PNG.
"""
import re, sys, json, pathlib, subprocess
import pdfplumber

Q_START = re.compile(r'^\d{1,2}\.\s+(?![).])\S')
DPI = 200


def question_anchors(pdf):
    """[(page_index, top_y, порядковый номер вопроса)] — по строкам вида '  12.   №11. ...'"""
    out = []
    for pi, page in enumerate(pdf.pages):
        for line in page.extract_text_lines() or []:
            txt = line['text']
            # номер пункта стоит в левой колонке; повтор номера в русской
            # половине вопроса идёт с отступом — его пропускаем
            if line['x0'] > 80:
                continue
            if Q_START.match(txt) and not re.search(
                    r'(аты[- ]жөні|телефон нөмір|сыныбыңыз|ФИО|Класс)', txt, re.I):
                out.append([pi, line['top'], None])
    out.sort(key=lambda r: (r[0], r[1]))
    for i, r in enumerate(out):
        r[2] = i + 1          # вопросы нумеруются подряд по всему документу
    return out


def crop(pdf_path, out_dir, tag):
    out_dir = pathlib.Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    found = {}
    with pdfplumber.open(pdf_path) as pdf:
        anchors = question_anchors(pdf)
        for pi, page in enumerate(pdf.pages):
            imgs = [im for im in (page.images or [])
                    if (im['x1'] - im['x0']) > 40 and (im['bottom'] - im['top']) > 25]
            if not imgs:
                continue
            here = [a for a in anchors if a[0] == pi]
            for im in imgs:
                # вопрос, чей заголовок выше картинки и ближе всех к ней
                owner = None
                for a in here:
                    if a[1] <= im['top'] + 4:
                        owner = a[2]
                if owner is None:
                    prev = [a for a in anchors if (a[0], a[1]) < (pi, im['top'])]
                    owner = prev[-1][2] if prev else None
                if owner is None:
                    continue
                found.setdefault(owner, []).append((pi, im))

    for qn, items in sorted(found.items()):
        with pdfplumber.open(pdf_path) as pdf:
            for k, (pi, im) in enumerate(items):
                page = pdf.pages[pi]
                pad = 6
                box = (max(0, im['x0'] - pad), max(0, im['top'] - pad),
                       min(page.width, im['x1'] + pad), min(page.height, im['bottom'] + pad))
                name = f"{tag}-q{qn:02d}" + (f"-{k+1}" if len(items) > 1 else "") + ".png"
                page.crop(box).to_image(resolution=DPI).save(str(out_dir / name))
    return {qn: len(v) for qn, v in found.items()}


if __name__ == '__main__':
    pdf_path, tag = sys.argv[1], sys.argv[2]
    res = crop(pdf_path, '/home/claude/zerdeli-tests/tests/images', tag)
    print(tag, '→ картинки у вопросов:', json.dumps(res, ensure_ascii=False))
