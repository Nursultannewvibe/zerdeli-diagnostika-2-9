#!/usr/bin/env python3
"""Восстанавливает ключ ответов по баллам учеников.

В таблицах ответов Google-формы нет служебного листа с ключом, но есть колонка
«Баллы» — сколько ученик набрал. Балл = (число совпадений с ключом) × цена вопроса.
Значит ключ — это вектор, при котором предсказанные баллы совпадают с фактическими
у ВСЕХ учеников сразу. Ищем его: голосование, взвешенное баллом, затем спуск —
меняем ответ на один вопрос, если суммарная невязка падает.

Ключ считается достоверным только при нулевой невязке (совпало у всех до балла).
"""
import sys, random, pathlib
from collections import defaultdict

LETTERS = 'ABCDE'


def parse(path):
    tests, cur = [], None
    for line in pathlib.Path(path).read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        if line.startswith('==='):
            tid, nq, per = [p.strip() for p in line.strip('= ').split('|')]
            cur = {'id': tid, 'nq': int(nq), 'per': int(per), 'rows': []}
            tests.append(cur)
        elif '|' in line and cur:
            s, rest = line.split('|', 1)
            ans = rest.split()
            if len(ans) != cur['nq']:
                print(f"  ! {cur['id']}: строка с {len(ans)} ответами вместо {cur['nq']} — пропущена")
                continue
            cur['rows'].append((int(s), ans))
    return tests


def residual(key, rows, per):
    """Сумма расхождений между предсказанным и фактическим баллом."""
    tot = 0
    for score, ans in rows:
        hit = sum(1 for k, a in zip(key, ans) if a == k)
        tot += abs(hit * per - score)
    return tot


def alphabet(t):
    """Допустимые буквы по каждому вопросу.

    Считать только по ответам учеников нельзя: верный вариант могли не выбрать
    вообще (так было в 7-алгебре, вопрос 15). Берём число вариантов из самого
    теста, а если теста нет — все буквы, что встречались хоть где-то в этом файле.
    """
    counts = t.get('opts')
    if counts:
        return [LETTERS[:n] for n in counts]
    wide = sorted({a for _, ans in t['rows'] for a in ans if a in LETTERS})
    return [wide or ['A']] * t['nq']


def solve(t, restarts=60, seed=7):
    rows, nq, per = t['rows'], t['nq'], t['per']
    seen = alphabet(t)
    rnd = random.Random(seed)

    # старт — голосование, взвешенное баллом ученика
    vote = [defaultdict(float) for _ in range(nq)]
    for score, ans in rows:
        w = score / (nq * per) - 0.5
        for i, a in enumerate(ans):
            if a in LETTERS:
                vote[i][a] += w
    best = [max(seen[i], key=lambda L: vote[i].get(L, 0)) for i in range(nq)]
    bestr = residual(best, rows, per)

    for attempt in range(restarts):
        key = best[:] if attempt == 0 else [rnd.choice(seen[i]) for i in range(nq)]
        r = residual(key, rows, per)
        improved = True
        while improved and r:
            improved = False
            for i in rnd.sample(range(nq), nq):
                for L in seen[i]:
                    if L == key[i]:
                        continue
                    old, key[i] = key[i], L
                    nr = residual(key, rows, per)
                    if nr < r:
                        r, improved = nr, True
                    else:
                        key[i] = old
        if r < bestr:
            best, bestr = key[:], r
        if bestr == 0:
            break
    return best, bestr


def confirm(key, t):
    """Единственность: можно ли поменять один вопрос без роста невязки."""
    amb, base, alpha = [], residual(key, t['rows'], t['per']), alphabet(t)
    for i in range(t['nq']):
        for L in alpha[i]:
            if L == key[i]:
                continue
            k2 = key[:]; k2[i] = L
            if residual(k2, t['rows'], t['per']) <= base:
                amb.append(i + 1); break
    return amb


def load_option_counts(tid):
    import json
    p = pathlib.Path(__file__).parent.parent / 'tests' / (tid + '.json')
    if not p.exists():
        return None
    d = json.loads(p.read_text(encoding='utf-8'))
    return [len(q.get('options') or []) or 5 for q in d['questions']]


def run(path):
    out = {}
    for t in parse(path):
        t['opts'] = load_option_counts(t['id'])
        if t['opts'] and len(t['opts']) != t['nq']:
            print(f"  ! {t['id']}: в тесте {len(t['opts'])} вопросов, в таблице {t['nq']}")
            t['opts'] = None
        key, r = solve(t)
        amb = confirm(key, t) if r == 0 else []
        # сколько учеников подтверждают ключ до балла
        exact = sum(1 for s, a in t['rows']
                    if sum(1 for k, x in zip(key, a) if x == k) * t['per'] == s)
        status = ('ТОЧНО' if not amb else 'неоднозначно: ' + ','.join(map(str, amb))) \
            if r == 0 else f'НЕ СОШЁЛСЯ, невязка {r}'
        print(f"\n=== {t['id']} === строк {len(t['rows'])}, вопросов {t['nq']}, "
              f"сошлось у {exact}/{len(t['rows'])} — {status}")
        print('ключ:', ' '.join(f'{i+1}={L}' for i, L in enumerate(key)))
        out[t['id']] = {'key': key, 'residual': r, 'ambiguous': amb,
                        'rows': len(t['rows']), 'exact': exact}
    return out


if __name__ == '__main__':
    run(sys.argv[1] if len(sys.argv) > 1
        else pathlib.Path(__file__).parent / 'otvety_uchenikov.txt')
